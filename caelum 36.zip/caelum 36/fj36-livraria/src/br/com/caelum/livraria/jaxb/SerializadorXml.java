package br.com.caelum.livraria.jaxb;


public class SerializadorXml {

//	public String toXml(Pedido pedido) {
//		//aqui vem o codigo do marshaller
//	}

}
