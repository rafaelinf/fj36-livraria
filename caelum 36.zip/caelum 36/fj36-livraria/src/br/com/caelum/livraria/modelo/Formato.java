package br.com.caelum.livraria.modelo;

public enum Formato {
	
	EBOOK,IMPRESSO;

}
